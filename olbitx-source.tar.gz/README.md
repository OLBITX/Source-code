Development moved to https://gitlab.com/blacknet-ninja

https://olbitx.org/ aims to continue on OLBITX chain.
